"""
Authentication module for Halo plugin.
"""

from .authenticator import HaloAuthenticator

__all__ = ["HaloAuthenticator"] 